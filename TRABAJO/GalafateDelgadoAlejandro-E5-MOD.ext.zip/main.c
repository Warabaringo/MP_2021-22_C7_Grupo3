#include <stdio.h>
#include <stdlib.h>
#include "lib.h"

usuario a[3];

int main() {
	
		// Establecer el idioma a espa�ol
    	setlocale(LC_ALL, "spanish"); // Cambiar locale - Suficiente para m�quinas Linux
    	SetConsoleCP(1252); // Cambiar STDIN -  Para m�quinas Windows
    	SetConsoleOutputCP(1252); // Cambiar STDOUT - Para m�quinas Windows	
	
	char log[6],con[9],op1;
	int i,aux,cont,gr;
	
	FILE *f;

	vacio();
	ad_usuario();
	system("pause");
	system("cls");
	ver_usuario();
	system("pause");
	system("cls");
	
	printf("     	   BINENVENIDO\n----------------------------------\n----------------------------------\n\n");
/*	
	printf("Introduce tu usuario y contrase�a\n\n");
	system("pause");
	system("cls");

	cont=0;
	login://PUNTO DE VUELTA PARA INTRODUCIR USUARIO	
											//INTRODUCIR USUARIO
	printf("Usuario: ");
	fflush(stdin);
	fgets(log,5,stdin);
	fflush(stdin);
											//COMPARACION USUARIOS GUARDADOS CON EL INTRODUCIDO
	for(i=0;i<5 || strcmp(a[i].Usuario,log)==0;i++){
		if(strcmp(a[i].Usuario,log)==0){	
			printf("Usuario encontrado");
			system("pasue");
			system("cls");
		}else{
			printf("Usuario no encontradao");
			system("pause");
											//DECISI�N PARA VOLVER A INTRODUCIR USUARIO
			do{
				system("cls");
				printf("\n�Quieres intentarlo otra vez?	(S)i/(N)o	(Tienes 5 intentos en total)");
				fflush(stdin);
				scanf("%c",&op1);
			}while(op1!='s' && op1!='S' && op1!='n' && op1!='N');
													//CONTADOR PARA LIMITES DE INTENTOS
			if(cont==5){
				system("cls");
				printf("Has alcanzado el n�mero m�ximo de intentos, vuelva a intentarlo una vez reinicies el programa");
				system("pause");
				exit(1);	
			}else{
				if(op1=='s' || op1=='S'){
					cont++;
					system("cls");
					goto login;
				}else{
					system("cls");
					printf("Vuelve a intentarlo mas tarde");
					exit(1);
				}	
			}
		}
	
		system("pause");
		system("cls");
	
		cont=0;
		contrasena://PUNTO DE VUELTA PARA INTRODUCIR CONTRASE�A
											//INTRODUCIR CONTRASE�A
		printf("Contrase�a: ");
		fflush(stdin);
		fgets(con,8,stdin);
											//COMPARACION CONTRASE�AS GUARDADOS CON EL INTRODUCIDO
		if(strcmp(a[i].Contrasena,con)==0){	
			printf("Contrase�a encontrada");
			system("pasue");
			system("cls");
		}else{
			printf("Contrase�a no encontradao");
			system("pause");
											//DECISI�N PARA VOLVER A INTRODUCIR CONTRASE�A
			do{
				system("cls");
				printf("\n�Quieres intentarlo otra vez?	(S)i/(N)o	(Tienes 5 intentos en total)");
				fflush(stdin);
				scanf("%c",&op1);
			}while(op1!='s' && op1!='S' && op1!='n' && op1!='N');
											//CONTADOR PARA L�MITE DE INTENTOS
			if(cont==5){
				system("cls");
				printf("Has alcanzado el n�mero m�ximo de intentos, vuelva a intentarlo una vez reinicies el programa");
				system("pause");	
			}else{
				if(op1=='s' || op1=='S'){
					cont++;
					system("cls");
					goto login;
				}else{
					system("cls");
					printf("Vuelve a intentarlo mas tarde");
				}	
			}
		}	
	}
	
	system("cls");
	printf("Esta cuenta corresponde a un profesor");
	system("pause");
	profe://PUNTO DE VUELTA PARA VOLVER A SELECCIONAR GRUPO
	system("cls");
	printf("Bienvenido %s, �A qu� grupo desea acceder?",a[i].Nombre);
	printf("\n");
											//BUCLE PARA LITAR ALUMNOS O SELECCIONAR OTRO GRUPO
	do{
		system("cls");
		printf("\nGrupo %s	1.-Ver la lista de alumnos del grupo\n	2.-Volver a seleccionar grupo");
		fflush(stdin);
		scanf("%i",&gr);
		if(gr!=1 || gr!=2){
			printf("Opci�n no v�lida, vuelva a intentarlo");	
		}	
	}while(gr!=1 && gr!=2);
											//SWITCH PARA LITAR ALUMNOS O SELECCIONAR OTRO GRUPO
	switch(gr){
		case 1:
			break;
		case 2:		goto profe;
			break;
		default:	printf("3rRor!!");
					system("pause");
					exit(1);
			break;
	}
*/
	system("pause");
	return 0;
}












