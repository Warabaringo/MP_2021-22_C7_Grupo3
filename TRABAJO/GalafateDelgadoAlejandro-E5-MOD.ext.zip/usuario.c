#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lib.h"

usuario a[3];

void ad_usuario(){
	int i,id,p;
	char aux[4];
	char adm[]="Administrador";
	char pro[]="Profesor";
	char nom[21],us[6],con[9];
	
	for(i=0;i<999;i++){
		id=i+1;
									//ASIGNACI�N DE ID
		if(a[i].lleno==0){
			if(i<10){
				itoa(id,aux,10);
				strcpy(a[i].Id,"00");
				strcat(a[i].Id,aux);
			}else{
				if(i<100){
					itoa(id,aux,10);
					strcpy(a[i].Id,"0");
					strcat(a[i].Id,aux);
				}else{
					itoa(id,aux,10);
					strcpy(a[i].Id,aux);
				}
			}
			printf("Id: %s",a[i].Id);
									//LECTURA NOMBRE
			printf("\nNombre: ");
			fflush(stdin);
			fgets(nom,21,stdin);
			cambio(nom);
			strcpy(a[i].Nombre,nom);
									//LECTURA PERFIL
			do{
				printf("\nPerfil (1.-Administrador/2.-Profesor)[No puede cambiarse luego]: ");
				fflush(stdin);
				scanf("%i",&p);
				if(p==1){
					strcpy(a[i].Perfil,adm);
				}else{
					strcpy(a[i].Perfil,pro);
				}	
			}while(p!=1 && p!=2);
			p=0;
									//LECTURA USUARIO
			printf("\nUsuario: ");
			fflush(stdin);
			fgets(us,6,stdin);
			cambio(us);
			strcpy(a[i].Usuario,us);
									//LECTURA CONTRASE�A
			printf("\nContrasena: ");
			fflush(stdin);
			fgets(con,9,stdin);		
			cambio(con);
			strcpy(a[i].Contrasena,con);
			
			a[i].lleno=1;	
			i=1000;
		}
	}
}
				//SIN TERMINAR
void fichero(){
	int i=0,j=0;
	char aux[22];
	char token;
	FILE *f;

	f=fopen("hola.txt","r");
	if(f==NULL){
		printf("no se ha podido abrir el archivo");
		exit(1);
	}
	
	while(!feof(f)){
		v(aux);
		token=fgetc(f);
		if(token=='-'){
			j++;
		}
		if(token!='-' && token!='\n'){
			aux[i]=token;
			i++;
		}
		
		switch(j){
			case 0:
					strcpy(a[i].Id,aux);
					
				break;
			case 1:
					strcpy(a[i].Nombre,aux);
					
				break;
			case 2:
					strcpy(a[i].Perfil,aux);
					
				break;
			case 3:
					strcpy(a[i].Usuario,aux);
					
				break;
			case 4:
					strcpy(a[i].Contrasena,aux);
					j=0;
				break;
		}
		
	}
		
}

void v(char x[]){
	int i;
	
	for(i=0;i<25;i++){
		x[i]='\0';
	}
}

void ver_usuario(){
	int i;
	for(i=0;i<3;i++){
		if(a[i].lleno==1){
			printf("%s - %s - %s - %s - %s\n",a[i].Id,a[i].Nombre,a[i].Perfil,a[i].Usuario,a[i].Contrasena);
			printf("\n");
		}	
	}
}
//
void buscar(){
	
	int i,op;
	char aux[20], aux2[20];;
	printf("usuario: ");
	fflush(stdin);
	fgets(aux,5,stdin);
	cambio(aux);
	
	contra:
	
	printf("\ncontrasena: ");
	fflush(stdin);
	fgets(aux2,8,stdin);
	cambio(aux2);
	
	for(i=0;i<3;i++){
		if(strcmp(aux,a[i].Usuario)==0){
			
			if(strcmp(aux2,a[i].Contrasena)==0){
			
				system("cls");
				printf("Usuario encontrado\n");
				system("pause");
				system("cls");
				printf("Bienbenido");
				system("pause");
				break;
			
			}else{
				
				system("cls");
				printf("Contrasena incorrecta");
				system("pause");
				system("cls");
				printf("Desea introducir la constrasena de nuevo?");
				printf("\n1.-Si");
				printf("\n2.-No");
				scanf("%i",&op);
			
				if(op==1){
					system("cls");
					goto contra;				
				}else{
					exit(1);
				}
			}
		}else{
			system("cls");
			printf("Usuario no encontrado");
			exit(1);
		}	
	}
}

void vacio(){
	int i;
	for(i=0;i<5;i++){
		a[i].lleno=0;	
	}
}

void cambio(char palabra[25]){
	int i;
	for(i=0;i<25;i++){
		if(palabra[i]=='\n'){
			palabra[i]=='\0';
		}
	}
}






