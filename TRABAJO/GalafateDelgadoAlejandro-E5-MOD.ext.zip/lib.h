#ifndef _LIB_H_
#define _LIB_H_

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <windows.h>

#define N 20

//ESTRUCTURA PARA LOS DATOS DE CADA USUARIO

typedef struct{
char	Id[4];
char 	Nombre[21];
char	Perfil[16];
char	Usuario[6];
char	Contrasena[9]; 
int     lleno;
}usuario;
//Precondici�n:
//Postcondici�n:
void ad_usuario();
//Precondici�n:
//Postcondici�n:
void fichero();
//Precondici�n:
//Postcondici�n:
void v(char *);
//Precondici�n:
//Postcondici�n:
void ver_usuario();
//Precondici�n:
//Postcondici�n:
void buscar();
//Precondici�n:
//Postcondici�n:
void vacio();
//Precondici�n:
//Postcondici�n:
void cambio(char *);








#endif
