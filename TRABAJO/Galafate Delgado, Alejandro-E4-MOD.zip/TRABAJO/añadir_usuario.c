#include <stdio.h>
#include <stdlib.h>
#include "lib.h"

void ad(){
	
	usuario:		//RUTA DE INICIO (USUARIO)
	
	printf("Usuario: ");
	fflush(stdin);
	fgets(us[i].Usuario,N,stdin);	
	
	contrasena:		//RUTA DE INICIO (CONTRASE�A)
		
	printf("\nContrase�a: ");
	fflush(stdin);
	fgets(us[i].Contrasena,8,stdin);
	
	confirmar:		//RUTA DE CONFIRMACI�N 
	system("cls");
	
	printf("Usuario: %s",us[1].Usuario);
		printf("\nEste nombre de usuario es correcto? (S)i/(N)o\n");
		fflush(stdin);
		scanf("%c",&selec);
		if(selec=='n' || selec=='N'){
			us[i].Usuario == us[i+1].Usuario;
			goto usuario;
		}
	
	system("cls");
	
	printf("Contrase�a: %s",us[i].Contrasena);
		printf("\nEste nombre de usuario es correcto? (S)i/(N)o\n");
		fflush(stdin);
		scanf("%c",&selec);
		if(selec=='n' || selec=='N'){
			fflush(stdin);
			us[i].Contrasena == us[i+1].Contrasena;
			goto contrasena;
		}	
		
	system("cls");
	
	printf("Usuario: %s\nContrasena: %s\n",us[i].Usuario,us[i].Contrasena);
	
	system("cls");
	
	printf("Usuario correcto");		//USUARIO A�ADIDO CORRECTAMENTE

}
