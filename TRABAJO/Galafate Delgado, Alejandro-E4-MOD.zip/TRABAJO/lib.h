#ifndef _LIB_H_
#define _LIB_H_

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <windows.h>

#define N 20

//ESTRUCTURA PARA LOS DATOS DE CADA USUARIO

typedef struct{
char	Id[3];
char 	Nombre[20];
char	Perfil[15];
char	Usuario[5];
char	Contrasena[8]; 
int     lleno;
}usuario;

//void usuario();
void ad_usuario();
void fichero();
void v(char *);
void ver_usuario();
void buscar();
void vacio();
void cambio(char *);
#endif
