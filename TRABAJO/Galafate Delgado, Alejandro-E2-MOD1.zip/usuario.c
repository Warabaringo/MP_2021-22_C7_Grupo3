#include <stdio.h>
#include <stdlib.h>
#include "lib.h"

void usuarios(){
	
	int op1;
	
	menu1: //ACCESO DIRECTO MENU
	
	do{
		system("cls");
		printf("Que desea hacer?");     
		scanf("%i",&op1);	
	}while(op1!=1 && op1!=2 && op1!=3);
	
	printf("\n");
    printf("1.- Anadir usuario\n");   //Permite a�adir un usuario
    printf("2.- Editar usuario\n");     //Permite editar los datos de un usuario
    printf("3.- Eliminar usuario\n");   //Permite eliminar un usuario usuario

    switch(op1){

    case 1: system("cls");
            	anadir();	//FUNCI�N QUE A�ADE UN USUARIO
            break;
    case 2: system("cls");
            	editar();	//FUNCI�N QUE EDITA UN USUARIO
            break;
	case 3:  system("cls");
            	eliminar();	//FUNCI�N QUE ELIMINA UN USUARIO
            break;

    default:system("cls");
			printf("3rRor!");                     
            goto menu1;
			break;	
	}
}

