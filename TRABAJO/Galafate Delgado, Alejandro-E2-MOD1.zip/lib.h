#ifndef _LIB_H_
#define _LIB_H_

#include <stdio.h>
#include <stdlib.h>


typedef struct{
char	Id_usuario[3];
char	Nomb_usuario[20];
char	Perfil_usuario[13];
char	Usuario[5];
char	Contrasena[8];
}us;

void usuario();

void anadir();
void editar();
void eliminar();

#endif
