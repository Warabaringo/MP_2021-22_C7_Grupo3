#include <stdio.h>
#include <stdlib.h>
#include "lib.h"


int main() {
	
	char us,con;
	
	printf("     Bienvenido\n     ----------\n");
	
	printf("Introduce tu usuario y contrase�a\n\n");
	system("pause");
	system("cls");
	
	printf("Usuario: ");
	scanf("%s",&us);
	
	printf("\nContrase�a: ");
	fflush(stdin);
	scanf("&s",&con);
	
	usuario();
	
	system("pause");
	return 0;
}
